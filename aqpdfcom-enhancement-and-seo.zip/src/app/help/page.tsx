import { Metadata } from "next";
import Link from "next/link";
import { FileText, ArrowLeft, Book } from "lucide-react";

export const metadata: Metadata = {
  title: "Help Center - AQPDF Documentation",
  description: "Learn how to use AQPDF tools with our comprehensive guides and tutorials.",
  alternates: { canonical: "https://aqpdf.com/help" },
};

export default function HelpPage() {
  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">AQPDF</span>
            </Link>
            <Link href="/" className="flex items-center space-x-2 text-slate-600 hover:text-blue-600 transition-colors">
              <ArrowLeft className="h-5 w-5" /><span>Home</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 mb-6">
              <Book className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Help Center</h1>
            <p className="text-xl text-slate-600">Everything you need to know about using AQPDF</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Link href="/help/merge-pdf" className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow">
              <h3 className="text-xl font-semibold mb-2">How to Merge PDFs</h3>
              <p className="text-slate-600">Learn how to combine multiple PDF files into one document</p>
            </Link>

            <Link href="/help/compress-pdf" className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow">
              <h3 className="text-xl font-semibold mb-2">How to Compress PDFs</h3>
              <p className="text-slate-600">Reduce PDF file size without losing quality</p>
            </Link>

            <Link href="/faq" className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow">
              <h3 className="text-xl font-semibold mb-2">FAQs</h3>
              <p className="text-slate-600">Find answers to frequently asked questions</p>
            </Link>

            <Link href="/contact" className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow">
              <h3 className="text-xl font-semibold mb-2">Contact Support</h3>
              <p className="text-slate-600">Get help from our support team</p>
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}
