import { MetadataRoute } from 'next'

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = 'https://aqpdf.com'
  
  const tools = [
    'merge-pdf',
    'split-pdf',
    'compress-pdf',
    'pdf-to-image',
    'image-to-pdf',
    'pdf-to-excel',
    'protect-pdf',
    'unlock-pdf',
    'rotate-pdf',
    'delete-pages',
    'edit-pdf',
    'sign-pdf',
  ]
  
  const pages = [
    'about',
    'privacy',
    'terms',
    'contact',
    'faq',
    'help',
    'blog',
  ]
  
  const routes = [
    {
      url: baseUrl,
      lastModified: new Date(),
      changeFrequency: 'daily' as const,
      priority: 1,
    },
    ...tools.map((tool) => ({
      url: `${baseUrl}/${tool}`,
      lastModified: new Date(),
      changeFrequency: 'weekly' as const,
      priority: 0.9,
    })),
    ...pages.map((page) => ({
      url: `${baseUrl}/${page}`,
      lastModified: new Date(),
      changeFrequency: 'monthly' as const,
      priority: 0.7,
    })),
  ]

  return routes
}
