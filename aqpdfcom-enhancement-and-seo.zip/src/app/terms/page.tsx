import { Metadata } from "next";
import Link from "next/link";
import { FileText, ArrowLeft, FileCheck } from "lucide-react";

export const metadata: Metadata = {
  title: "Terms of Service - AQPDF",
  description: "AQPDF terms of service. Read our terms and conditions for using our free PDF tools.",
  alternates: {
    canonical: "https://aqpdf.com/terms",
  },
};

export default function TermsPage() {
  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AQPDF
              </span>
            </Link>
            <Link 
              href="/" 
              className="flex items-center space-x-2 text-slate-600 hover:text-blue-600 transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
              <span>Home</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 mb-6">
              <FileCheck className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Terms of Service
            </h1>
            <p className="text-slate-600">
              Last updated: January 2024
            </p>
          </div>

          <div className="prose prose-slate max-w-none bg-white rounded-2xl shadow-lg p-8">
            <h2>1. Acceptance of Terms</h2>
            <p>
              By accessing and using AQPDF services, you accept and agree to be bound by these Terms of Service. 
              If you do not agree to these terms, please do not use our services.
            </p>

            <h2>2. Description of Service</h2>
            <p>
              AQPDF provides free online PDF tools including but not limited to merging, splitting, compressing, 
              converting, and editing PDF files. We reserve the right to modify or discontinue any service at any time.
            </p>

            <h2>3. User Responsibilities</h2>
            <p>You agree to:</p>
            <ul>
              <li>Use our services only for lawful purposes</li>
              <li>Not upload files containing malware, viruses, or harmful code</li>
              <li>Not attempt to hack, disrupt, or damage our services</li>
              <li>Not use our services to violate intellectual property rights</li>
              <li>Not upload copyrighted material without proper authorization</li>
              <li>Not abuse our services through excessive or automated usage</li>
            </ul>

            <h2>4. File Ownership and Responsibility</h2>
            <p>
              You retain all ownership rights to files you upload. You are solely responsible for the content 
              of files you upload and process through our services. We are not responsible for any loss or 
              damage to your files.
            </p>

            <h2>5. Service Availability</h2>
            <p>
              We strive to provide reliable services, but we do not guarantee uninterrupted access. 
              Services may be temporarily unavailable due to maintenance, updates, or technical issues.
            </p>

            <h2>6. Disclaimer of Warranties</h2>
            <p>
              Our services are provided "as is" without warranties of any kind. We do not guarantee 
              that our services will meet your requirements or that they will be error-free.
            </p>

            <h2>7. Limitation of Liability</h2>
            <p>
              AQPDF shall not be liable for any indirect, incidental, special, or consequential damages 
              arising from the use of our services. Our total liability shall not exceed the amount you 
              paid to use our services (which is $0 for free services).
            </p>

            <h2>8. File Processing and Storage</h2>
            <ul>
              <li>Files are processed on our secure servers</li>
              <li>All files are automatically deleted after 1 hour</li>
              <li>We do not permanently store your files</li>
              <li>Maximum file size limits may apply</li>
            </ul>

            <h2>9. Prohibited Uses</h2>
            <p>You may not use our services to:</p>
            <ul>
              <li>Process illegal or harmful content</li>
              <li>Violate any laws or regulations</li>
              <li>Infringe on intellectual property rights</li>
              <li>Distribute spam or malicious software</li>
              <li>Engage in fraudulent activities</li>
            </ul>

            <h2>10. Intellectual Property</h2>
            <p>
              All content, features, and functionality of AQPDF are owned by us and protected by 
              copyright, trademark, and other intellectual property laws.
            </p>

            <h2>11. Privacy</h2>
            <p>
              Your use of our services is also governed by our Privacy Policy. Please review our 
              Privacy Policy to understand how we collect and use information.
            </p>

            <h2>12. Changes to Terms</h2>
            <p>
              We reserve the right to modify these terms at any time. Changes will be effective 
              immediately upon posting. Your continued use of our services constitutes acceptance 
              of modified terms.
            </p>

            <h2>13. Termination</h2>
            <p>
              We may terminate or suspend access to our services immediately, without notice, for 
              any violation of these Terms of Service.
            </p>

            <h2>14. Governing Law</h2>
            <p>
              These terms shall be governed by and construed in accordance with applicable laws, 
              without regard to conflict of law provisions.
            </p>

            <h2>15. Contact Information</h2>
            <p>
              If you have questions about these Terms of Service, please contact us at:
              <br />
              Email: <a href="mailto:legal@aqpdf.com">legal@aqpdf.com</a>
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
