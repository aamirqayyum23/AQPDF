import { Metadata } from "next";
import Link from "next/link";
import { FileText, ArrowLeft, HelpCircle } from "lucide-react";

export const metadata: Metadata = {
  title: "Frequently Asked Questions (FAQ) - AQPDF",
  description: "Find answers to common questions about using AQPDF tools, file security, pricing, and more.",
  keywords: ["pdf faq", "pdf questions", "pdf help", "pdf support"],
  alternates: {
    canonical: "https://aqpdf.com/faq",
  },
};

const faqs = [
  {
    question: "Is AQPDF really free to use?",
    answer: "Yes! All our PDF tools are completely free to use. There are no hidden fees, subscriptions, or registration requirements."
  },
  {
    question: "Are my files secure?",
    answer: "Absolutely. We use SSL encryption to protect your files during upload and processing. All files are automatically deleted from our servers after 1 hour to ensure your privacy."
  },
  {
    question: "Do I need to create an account?",
    answer: "No, you don't need to create an account or register. Simply visit the tool you need and start processing your PDFs immediately."
  },
  {
    question: "What is the maximum file size I can upload?",
    answer: "Currently, you can upload PDF files up to 100 MB. If you need to process larger files, please compress them first or contact our support team."
  },
  {
    question: "How long does it take to process a PDF?",
    answer: "Most operations take just a few seconds. Processing time depends on the file size and the complexity of the operation, but typically completes within 10-30 seconds."
  },
  {
    question: "Can I use AQPDF on mobile devices?",
    answer: "Yes! AQPDF is fully responsive and works on all devices including smartphones, tablets, and desktop computers."
  },
  {
    question: "Do you store my files?",
    answer: "No. All uploaded files are automatically deleted from our servers after 1 hour. We do not store, share, or use your files for any purpose other than processing."
  },
  {
    question: "What file formats do you support?",
    answer: "We support PDF files and common image formats (JPG, PNG, GIF) for conversion. More formats are being added regularly."
  },
  {
    question: "Can I process multiple files at once?",
    answer: "Yes, tools like Merge PDF allow you to upload and process multiple files simultaneously."
  },
  {
    question: "Is there a limit on how many files I can process?",
    answer: "No, there's no limit. You can process as many files as you need, completely free."
  },
  {
    question: "How do I compress a PDF without losing quality?",
    answer: "Use our Compress PDF tool with the 'Low Compression' or 'Medium Compression' option. This reduces file size while maintaining good visual quality."
  },
  {
    question: "Can I password-protect my PDF?",
    answer: "Yes! Use our Protect PDF tool to add password protection to your documents."
  },
  {
    question: "What happens if I close the browser during processing?",
    answer: "If you close the browser, the processing will stop. You'll need to re-upload your file and start again."
  },
  {
    question: "Do you offer customer support?",
    answer: "Yes, we offer email support for all users. Contact us through our contact page and we'll respond within 24 hours."
  },
  {
    question: "Can I use AQPDF for commercial purposes?",
    answer: "Yes, you can use AQPDF for both personal and commercial purposes at no cost."
  }
];

export default function FAQPage() {
  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AQPDF
              </span>
            </Link>
            <Link 
              href="/" 
              className="flex items-center space-x-2 text-slate-600 hover:text-blue-600 transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
              <span>Home</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 mb-6">
              <HelpCircle className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Frequently Asked Questions
            </h1>
            <p className="text-xl text-slate-600">
              Find answers to common questions about AQPDF
            </p>
          </div>

          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <div 
                key={index}
                className="bg-white rounded-2xl shadow-md p-6 border border-slate-100 hover:shadow-lg transition-shadow"
              >
                <h2 className="text-xl font-semibold mb-3 text-slate-900 flex items-start">
                  <span className="text-blue-600 mr-3 text-2xl">Q:</span>
                  {faq.question}
                </h2>
                <div className="pl-10">
                  <p className="text-slate-700 leading-relaxed">
                    <span className="text-purple-600 font-semibold mr-2">A:</span>
                    {faq.answer}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Still have questions?</h2>
            <p className="text-slate-700 mb-6">
              Can't find the answer you're looking for? Contact our support team.
            </p>
            <Link 
              href="/contact"
              className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full font-semibold hover:shadow-xl transition-all transform hover:scale-105"
            >
              Contact Support
            </Link>
          </div>
        </div>
      </main>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": faqs.map(faq => ({
              "@type": "Question",
              "name": faq.question,
              "acceptedAnswer": {
                "@type": "Answer",
                "text": faq.answer
              }
            }))
          })
        }}
      />
    </div>
  );
}
