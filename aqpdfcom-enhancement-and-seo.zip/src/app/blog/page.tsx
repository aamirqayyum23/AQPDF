import { Metadata } from "next";
import Link from "next/link";
import { FileText, ArrowLeft, Calendar, User } from "lucide-react";

export const metadata: Metadata = {
  title: "PDF Tips & Tutorials Blog - AQPDF",
  description: "Learn PDF tips, tricks, and best practices. Tutorials on how to work with PDF files efficiently.",
  keywords: ["pdf tutorial", "pdf tips", "pdf guide", "pdf best practices"],
  alternates: {
    canonical: "https://aqpdf.com/blog",
  },
};

const blogPosts = [
  {
    title: "10 Best Ways to Reduce PDF File Size",
    excerpt: "Learn effective techniques to compress your PDF files without losing quality. Perfect for email attachments and web sharing.",
    date: "2024-01-15",
    author: "AQPDF Team",
    slug: "reduce-pdf-file-size"
  },
  {
    title: "How to Merge Multiple PDFs into One Document",
    excerpt: "Step-by-step guide on combining multiple PDF files into a single document for easier management and sharing.",
    date: "2024-01-10",
    author: "AQPDF Team",
    slug: "merge-multiple-pdfs"
  },
  {
    title: "PDF Security Best Practices",
    excerpt: "Protect your sensitive documents with password encryption and learn about PDF security features.",
    date: "2024-01-05",
    author: "AQPDF Team",
    slug: "pdf-security-best-practices"
  },
  {
    title: "Converting Images to PDF: Complete Guide",
    excerpt: "Learn how to convert JPG, PNG, and other image formats to PDF with optimal quality settings.",
    date: "2024-01-01",
    author: "AQPDF Team",
    slug: "converting-images-to-pdf"
  },
];

export default function BlogPage() {
  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AQPDF
              </span>
            </Link>
            <Link 
              href="/" 
              className="flex items-center space-x-2 text-slate-600 hover:text-blue-600 transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
              <span>Home</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              PDF Tips & Tutorials
            </h1>
            <p className="text-xl text-slate-600">
              Learn how to work with PDFs more efficiently
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {blogPosts.map((post, index) => (
              <article 
                key={index}
                className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow p-6 border border-slate-100"
              >
                <h2 className="text-2xl font-bold mb-3 text-slate-900 hover:text-blue-600">
                  <Link href={`/blog/${post.slug}`}>
                    {post.title}
                  </Link>
                </h2>
                <p className="text-slate-600 mb-4">
                  {post.excerpt}
                </p>
                <div className="flex items-center justify-between text-sm text-slate-500">
                  <div className="flex items-center space-x-4">
                    <span className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      {new Date(post.date).toLocaleDateString()}
                    </span>
                    <span className="flex items-center">
                      <User className="h-4 w-4 mr-1" />
                      {post.author}
                    </span>
                  </div>
                  <Link 
                    href={`/blog/${post.slug}`}
                    className="text-blue-600 hover:text-blue-700 font-semibold"
                  >
                    Read More →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </main>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Blog",
            "name": "AQPDF Blog",
            "description": "PDF tips, tutorials, and best practices",
            "url": "https://aqpdf.com/blog",
            "publisher": {
              "@type": "Organization",
              "name": "AQPDF"
            }
          })
        }}
      />
    </div>
  );
}
