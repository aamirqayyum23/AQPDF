import { db } from "@/db";
import { sql } from "drizzle-orm";
import Link from "next/link";
import { 
  FileText, 
  Combine, 
  Scissors, 
  Minimize2, 
  FileImage, 
  FileSpreadsheet,
  Lock,
  Unlock,
  RotateCw,
  Trash2,
  Edit3,
  Download,
  Upload,
  CheckCircle,
  Shield,
  Zap,
  Globe
} from "lucide-react";

export const dynamic = "force-dynamic";

const tools = [
  {
    title: "Merge PDF",
    description: "Combine multiple PDF files into one document",
    icon: Combine,
    href: "/merge-pdf",
    color: "from-blue-500 to-blue-600"
  },
  {
    title: "Split PDF",
    description: "Extract pages or split PDF into multiple files",
    icon: Scissors,
    href: "/split-pdf",
    color: "from-purple-500 to-purple-600"
  },
  {
    title: "Compress PDF",
    description: "Reduce PDF file size without losing quality",
    icon: Minimize2,
    href: "/compress-pdf",
    color: "from-green-500 to-green-600"
  },
  {
    title: "PDF to Image",
    description: "Convert PDF pages to JPG or PNG images",
    icon: FileImage,
    href: "/pdf-to-image",
    color: "from-orange-500 to-orange-600"
  },
  {
    title: "Image to PDF",
    description: "Convert images to PDF documents",
    icon: FileText,
    href: "/image-to-pdf",
    color: "from-pink-500 to-pink-600"
  },
  {
    title: "PDF to Excel",
    description: "Convert PDF tables to Excel spreadsheets",
    icon: FileSpreadsheet,
    href: "/pdf-to-excel",
    color: "from-teal-500 to-teal-600"
  },
  {
    title: "Protect PDF",
    description: "Add password protection to your PDFs",
    icon: Lock,
    href: "/protect-pdf",
    color: "from-red-500 to-red-600"
  },
  {
    title: "Unlock PDF",
    description: "Remove password from PDF files",
    icon: Unlock,
    href: "/unlock-pdf",
    color: "from-indigo-500 to-indigo-600"
  },
  {
    title: "Rotate PDF",
    description: "Rotate PDF pages to any orientation",
    icon: RotateCw,
    href: "/rotate-pdf",
    color: "from-yellow-500 to-yellow-600"
  },
  {
    title: "Delete Pages",
    description: "Remove unwanted pages from PDF",
    icon: Trash2,
    href: "/delete-pages",
    color: "from-rose-500 to-rose-600"
  },
  {
    title: "Edit PDF",
    description: "Add text, images, and shapes to PDF",
    icon: Edit3,
    href: "/edit-pdf",
    color: "from-cyan-500 to-cyan-600"
  },
  {
    title: "Sign PDF",
    description: "Add electronic signatures to PDF files",
    icon: Edit3,
    href: "/sign-pdf",
    color: "from-violet-500 to-violet-600"
  },
];

const features = [
  {
    icon: Shield,
    title: "100% Secure",
    description: "Your files are encrypted and automatically deleted after 1 hour"
  },
  {
    icon: Zap,
    title: "Lightning Fast",
    description: "Process your PDFs in seconds with our optimized servers"
  },
  {
    icon: Globe,
    title: "Works Anywhere",
    description: "Access from any device - desktop, tablet, or mobile"
  },
  {
    icon: CheckCircle,
    title: "No Registration",
    description: "Use all tools for free without creating an account"
  }
];

export default async function HomePage() {
  await db.execute(sql`select 1`);

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AQPDF
              </span>
            </Link>
            <nav className="hidden md:flex items-center space-x-6">
              <Link href="#tools" className="text-slate-600 hover:text-blue-600 transition-colors">
                Tools
              </Link>
              <Link href="#features" className="text-slate-600 hover:text-blue-600 transition-colors">
                Features
              </Link>
              <Link href="#about" className="text-slate-600 hover:text-blue-600 transition-colors">
                About
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl text-center">
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent leading-tight">
            All-in-One PDF Tools
          </h1>
          <p className="text-xl md:text-2xl text-slate-600 mb-8 max-w-3xl mx-auto">
            Free online PDF tools to merge, split, compress, convert, and edit your documents. 
            Fast, secure, and easy to use - no registration required.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a 
              href="#tools" 
              className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full font-semibold hover:shadow-xl transition-all transform hover:scale-105"
            >
              <Upload className="mr-2 h-5 w-5" />
              Get Started Free
            </a>
            <a 
              href="#features" 
              className="inline-flex items-center px-8 py-4 bg-white text-blue-600 rounded-full font-semibold hover:shadow-lg transition-all border-2 border-blue-600"
            >
              Learn More
            </a>
          </div>
        </div>
      </section>

      {/* Tools Grid */}
      <section id="tools" className="py-16 px-4">
        <div className="container mx-auto max-w-7xl">
          <h2 className="text-4xl font-bold text-center mb-4">
            All PDF Tools You Need
          </h2>
          <p className="text-center text-slate-600 mb-12 text-lg">
            Choose from our collection of powerful PDF tools
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {tools.map((tool, index) => {
              const Icon = tool.icon;
              return (
                <Link
                  key={index}
                  href={tool.href}
                  className="group bg-white rounded-2xl p-6 shadow-md hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-slate-100"
                >
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${tool.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                    <Icon className="h-7 w-7 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2 text-slate-900">
                    {tool.title}
                  </h3>
                  <p className="text-slate-600 text-sm">
                    {tool.description}
                  </p>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 px-4 bg-white">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-4xl font-bold text-center mb-4">
            Why Choose AQPDF?
          </h2>
          <p className="text-center text-slate-600 mb-12 text-lg">
            The best online PDF tools for all your needs
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center mx-auto mb-4">
                    <Icon className="h-8 w-8 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-slate-600">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-4xl font-bold text-center mb-12">
            How It Works
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-blue-600 text-white flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                1
              </div>
              <h3 className="text-xl font-semibold mb-2">Upload</h3>
              <p className="text-slate-600">
                Select your PDF file or drag and drop it
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-purple-600 text-white flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                2
              </div>
              <h3 className="text-xl font-semibold mb-2">Process</h3>
              <p className="text-slate-600">
                Choose your tool and let us process it
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-pink-600 text-white flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                3
              </div>
              <h3 className="text-xl font-semibold mb-2">Download</h3>
              <p className="text-slate-600">
                Download your processed file instantly
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 px-4 bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-4xl font-bold mb-6">About AQPDF</h2>
          <p className="text-lg text-slate-700 mb-4">
            AQPDF is a free online platform providing professional PDF tools for everyone. 
            Whether you need to merge, split, compress, or convert PDFs, we've got you covered.
          </p>
          <p className="text-lg text-slate-700">
            Our mission is to make PDF manipulation simple, fast, and accessible to all users 
            without any registration or subscription fees. Your privacy and security are our top priorities.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <FileText className="h-6 w-6" />
                <span className="text-xl font-bold">AQPDF</span>
              </div>
              <p className="text-slate-400">
                Professional PDF tools for everyone. Free, fast, and secure.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Popular Tools</h4>
              <ul className="space-y-2 text-slate-400">
                <li><Link href="/merge-pdf" className="hover:text-white transition-colors">Merge PDF</Link></li>
                <li><Link href="/split-pdf" className="hover:text-white transition-colors">Split PDF</Link></li>
                <li><Link href="/compress-pdf" className="hover:text-white transition-colors">Compress PDF</Link></li>
                <li><Link href="/pdf-to-image" className="hover:text-white transition-colors">PDF to Image</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-slate-400">
                <li><Link href="/about" className="hover:text-white transition-colors">About Us</Link></li>
                <li><Link href="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link></li>
                <li><Link href="/terms" className="hover:text-white transition-colors">Terms of Service</Link></li>
                <li><Link href="/contact" className="hover:text-white transition-colors">Contact</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-slate-400">
                <li><Link href="/faq" className="hover:text-white transition-colors">FAQ</Link></li>
                <li><Link href="/help" className="hover:text-white transition-colors">Help Center</Link></li>
                <li><Link href="/blog" className="hover:text-white transition-colors">Blog</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-800 pt-8 text-center text-slate-400">
            <p>&copy; {new Date().getFullYear()} AQPDF. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Structured Data for SEO */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebApplication",
            "name": "AQPDF",
            "description": "Free online PDF tools to merge, split, compress, convert, and edit PDF files",
            "url": "https://aqpdf.com",
            "applicationCategory": "UtilityApplication",
            "offers": {
              "@type": "Offer",
              "price": "0",
              "priceCurrency": "USD"
            },
            "operatingSystem": "Any"
          })
        }}
      />
    </div>
  );
}
