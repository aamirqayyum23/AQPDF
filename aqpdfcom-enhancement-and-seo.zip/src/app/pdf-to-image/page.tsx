import { Metadata } from "next";
import Link from "next/link";
import { FileText, FileImage, ArrowLeft, Upload } from "lucide-react";

export const metadata: Metadata = {
  title: "PDF to Image Converter - Convert PDF to JPG/PNG Online",
  description: "Convert PDF pages to JPG or PNG images online for free. High quality PDF to image conversion.",
  keywords: ["pdf to jpg", "pdf to png", "pdf to image", "convert pdf to image", "pdf image converter"],
  alternates: {
    canonical: "https://aqpdf.com/pdf-to-image",
  },
};

export default function PDFToImagePage() {
  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AQPDF
              </span>
            </Link>
            <Link href="/" className="flex items-center space-x-2 text-slate-600 hover:text-blue-600 transition-colors">
              <ArrowLeft className="h-5 w-5" />
              <span>All Tools</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-orange-500 to-orange-600 mb-6">
              <FileImage className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">PDF to Image</h1>
            <p className="text-xl text-slate-600">Convert PDF pages to JPG or PNG images</p>
          </div>

          <div className="bg-white rounded-3xl shadow-xl p-12 mb-12 border-2 border-dashed border-slate-300 hover:border-orange-500 transition-colors">
            <div className="text-center">
              <Upload className="h-16 w-16 text-slate-400 mx-auto mb-6" />
              <h3 className="text-2xl font-semibold mb-2">Select PDF File</h3>
              <p className="text-slate-600 mb-6">Choose a PDF to convert to images</p>
              <button className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-orange-600 to-orange-700 text-white rounded-full font-semibold hover:shadow-xl transition-all transform hover:scale-105">
                <Upload className="mr-2 h-5 w-5" />
                Choose File
              </button>
            </div>
          </div>

          <article className="prose prose-slate max-w-none">
            <h2>Convert PDF to Image</h2>
            <p>Transform PDF pages into high-quality JPG or PNG images perfect for sharing and presentations.</p>
            
            <h3>Features</h3>
            <ul>
              <li>Convert to JPG or PNG format</li>
              <li>High resolution output</li>
              <li>Convert all pages or select specific ones</li>
              <li>Batch conversion supported</li>
            </ul>
          </article>
        </div>
      </main>
    </div>
  );
}
