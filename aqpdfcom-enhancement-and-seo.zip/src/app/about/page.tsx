import { Metadata } from "next";
import Link from "next/link";
import { FileText, ArrowLeft, Target, Users, Shield, Zap } from "lucide-react";

export const metadata: Metadata = {
  title: "About Us - AQPDF Free Online PDF Tools",
  description: "Learn about AQPDF's mission to provide free, secure, and easy-to-use PDF tools for everyone. No registration required.",
  keywords: ["about aqpdf", "pdf tools", "free pdf software"],
  alternates: {
    canonical: "https://aqpdf.com/about",
  },
};

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AQPDF
              </span>
            </Link>
            <Link 
              href="/" 
              className="flex items-center space-x-2 text-slate-600 hover:text-blue-600 transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
              <span>Home</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              About AQPDF
            </h1>
            <p className="text-xl text-slate-600">
              Professional PDF tools, accessible to everyone
            </p>
          </div>

          <div className="prose prose-slate max-w-none mb-12">
            <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
              <h2 className="text-3xl font-bold mb-4 flex items-center">
                <Target className="h-8 w-8 text-blue-600 mr-3" />
                Our Mission
              </h2>
              <p className="text-lg text-slate-700">
                At AQPDF, our mission is to provide free, secure, and easy-to-use PDF tools for everyone. 
                We believe that working with PDF files shouldn't require expensive software or complicated 
                installations. That's why we created a platform that's completely free and accessible from 
                any device with an internet connection.
              </p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-8 mb-8">
              <h2 className="text-3xl font-bold mb-6 text-center">Why Choose AQPDF?</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl p-6">
                  <div className="flex items-center mb-3">
                    <Shield className="h-8 w-8 text-blue-600 mr-3" />
                    <h3 className="text-xl font-semibold">100% Secure</h3>
                  </div>
                  <p className="text-slate-700">
                    Your files are encrypted during transfer and automatically deleted after 1 hour. 
                    We never store, share, or access your documents.
                  </p>
                </div>

                <div className="bg-white rounded-xl p-6">
                  <div className="flex items-center mb-3">
                    <Zap className="h-8 w-8 text-purple-600 mr-3" />
                    <h3 className="text-xl font-semibold">Lightning Fast</h3>
                  </div>
                  <p className="text-slate-700">
                    Our optimized servers process your PDFs in seconds, not minutes. 
                    Get your work done faster with AQPDF.
                  </p>
                </div>

                <div className="bg-white rounded-xl p-6">
                  <div className="flex items-center mb-3">
                    <Users className="h-8 w-8 text-green-600 mr-3" />
                    <h3 className="text-xl font-semibold">User-Friendly</h3>
                  </div>
                  <p className="text-slate-700">
                    Simple, intuitive interface that anyone can use. No technical knowledge required.
                  </p>
                </div>

                <div className="bg-white rounded-xl p-6">
                  <div className="flex items-center mb-3">
                    <FileText className="h-8 w-8 text-orange-600 mr-3" />
                    <h3 className="text-xl font-semibold">All-in-One</h3>
                  </div>
                  <p className="text-slate-700">
                    12+ PDF tools in one place. Merge, split, compress, convert, and more.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-3xl font-bold mb-4">What We Offer</h2>
              <p className="text-lg text-slate-700 mb-4">
                AQPDF provides a comprehensive suite of PDF tools designed to handle all your document needs:
              </p>
              <ul className="space-y-2 text-slate-700">
                <li>✓ Merge multiple PDFs into one document</li>
                <li>✓ Split PDFs into separate files</li>
                <li>✓ Compress PDFs to reduce file size</li>
                <li>✓ Convert PDFs to images and vice versa</li>
                <li>✓ Convert PDFs to Excel spreadsheets</li>
                <li>✓ Protect PDFs with passwords</li>
                <li>✓ Remove passwords from PDFs</li>
                <li>✓ Rotate PDF pages</li>
                <li>✓ Delete unwanted pages</li>
                <li>✓ Edit PDF content</li>
                <li>✓ Add electronic signatures</li>
              </ul>
            </div>
          </div>

          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white text-center">
            <h2 className="text-3xl font-bold mb-4">Join Millions of Users</h2>
            <p className="text-lg mb-6 opacity-90">
              Trusted by professionals, students, and businesses worldwide
            </p>
            <Link 
              href="/"
              className="inline-flex items-center px-8 py-4 bg-white text-blue-600 rounded-full font-semibold hover:shadow-xl transition-all transform hover:scale-105"
            >
              Start Using AQPDF Free
            </Link>
          </div>
        </div>
      </main>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Organization",
            "name": "AQPDF",
            "url": "https://aqpdf.com",
            "description": "Free online PDF tools for everyone",
            "sameAs": [
              "https://twitter.com/aqpdf",
              "https://facebook.com/aqpdf"
            ]
          })
        }}
      />
    </div>
  );
}
