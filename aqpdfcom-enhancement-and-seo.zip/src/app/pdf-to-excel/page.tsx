import { Metadata } from "next";
import Link from "next/link";
import { FileText, FileSpreadsheet, ArrowLeft, Upload } from "lucide-react";

export const metadata: Metadata = {
  title: "PDF to Excel Converter - Convert PDF Tables to Excel",
  description: "Convert PDF tables to Excel spreadsheets online. Extract data from PDF to XLSX format.",
  keywords: ["pdf to excel", "pdf to xlsx", "convert pdf to excel", "pdf table to excel"],
  alternates: { canonical: "https://aqpdf.com/pdf-to-excel" },
};

export default function PDFToExcelPage() {
  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">AQPDF</span>
            </Link>
            <Link href="/" className="flex items-center space-x-2 text-slate-600 hover:text-blue-600 transition-colors">
              <ArrowLeft className="h-5 w-5" /><span>All Tools</span>
            </Link>
          </div>
        </div>
      </header>
      <main className="py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-teal-500 to-teal-600 mb-6">
              <FileSpreadsheet className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">PDF to Excel</h1>
            <p className="text-xl text-slate-600">Convert PDF tables to Excel spreadsheets</p>
          </div>
          <div className="bg-white rounded-3xl shadow-xl p-12 border-2 border-dashed border-slate-300">
            <div className="text-center">
              <Upload className="h-16 w-16 text-slate-400 mx-auto mb-6" />
              <button className="px-8 py-4 bg-gradient-to-r from-teal-600 to-teal-700 text-white rounded-full font-semibold">Choose PDF</button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
