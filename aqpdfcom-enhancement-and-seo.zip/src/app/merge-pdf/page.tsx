import { Metadata } from "next";
import Link from "next/link";
import { FileText, Combine, ArrowLeft, Upload, Download } from "lucide-react";

export const metadata: Metadata = {
  title: "Merge PDF Files Online - Combine Multiple PDFs into One",
  description: "Free online tool to merge multiple PDF files into a single document. Easy, fast, and secure. No registration required.",
  keywords: ["merge pdf", "combine pdf", "join pdf", "pdf merger", "merge pdf online free"],
  alternates: {
    canonical: "https://aqpdf.com/merge-pdf",
  },
  openGraph: {
    title: "Merge PDF Files Online - AQPDF",
    description: "Combine multiple PDF files into one document for free",
    url: "https://aqpdf.com/merge-pdf",
  },
};

export default function MergePDFPage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AQPDF
              </span>
            </Link>
            <Link 
              href="/" 
              className="flex items-center space-x-2 text-slate-600 hover:text-blue-600 transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
              <span>All Tools</span>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          {/* Title */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-600 mb-6">
              <Combine className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Merge PDF Files
            </h1>
            <p className="text-xl text-slate-600">
              Combine multiple PDF documents into a single file
            </p>
          </div>

          {/* Upload Area */}
          <div className="bg-white rounded-3xl shadow-xl p-12 mb-12 border-2 border-dashed border-slate-300 hover:border-blue-500 transition-colors">
            <div className="text-center">
              <Upload className="h-16 w-16 text-slate-400 mx-auto mb-6" />
              <h3 className="text-2xl font-semibold mb-2">Select PDF Files</h3>
              <p className="text-slate-600 mb-6">
                Click to upload or drag and drop your PDF files here
              </p>
              <button className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full font-semibold hover:shadow-xl transition-all transform hover:scale-105">
                <Upload className="mr-2 h-5 w-5" />
                Choose Files
              </button>
              <p className="text-sm text-slate-500 mt-4">
                Your files will be securely processed and deleted after 1 hour
              </p>
            </div>
          </div>

          {/* How to Use */}
          <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-8 mb-12">
            <h2 className="text-2xl font-bold mb-6 text-center">How to Merge PDF Files</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center mx-auto mb-3 text-xl font-bold">
                  1
                </div>
                <h3 className="font-semibold mb-2">Upload PDFs</h3>
                <p className="text-sm text-slate-600">
                  Select multiple PDF files you want to merge
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-purple-600 text-white flex items-center justify-center mx-auto mb-3 text-xl font-bold">
                  2
                </div>
                <h3 className="font-semibold mb-2">Arrange Order</h3>
                <p className="text-sm text-slate-600">
                  Drag and drop files to arrange them in desired order
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-pink-600 text-white flex items-center justify-center mx-auto mb-3 text-xl font-bold">
                  3
                </div>
                <h3 className="font-semibold mb-2">Download</h3>
                <p className="text-sm text-slate-600">
                  Click merge and download your combined PDF
                </p>
              </div>
            </div>
          </div>

          {/* SEO Content */}
          <article className="prose prose-slate max-w-none">
            <h2>About PDF Merger Tool</h2>
            <p>
              Our free online PDF merger allows you to combine multiple PDF files into a single document 
              effortlessly. Whether you need to merge contracts, reports, or presentations, our tool 
              makes it simple and fast.
            </p>
            
            <h3>Features</h3>
            <ul>
              <li>Merge unlimited PDF files for free</li>
              <li>No file size restrictions</li>
              <li>Drag and drop interface for easy file arrangement</li>
              <li>100% secure - files are encrypted and auto-deleted</li>
              <li>Works on all devices - desktop, tablet, and mobile</li>
              <li>No software installation required</li>
            </ul>

            <h3>Why Merge PDF Files?</h3>
            <p>
              Merging PDFs is useful when you need to consolidate multiple documents into one file for 
              easier sharing, archiving, or presentation. Instead of sending multiple attachments, you 
              can combine them into a single PDF that's easier to manage.
            </p>

            <h3>Is It Safe to Merge PDFs Online?</h3>
            <p>
              Yes! We use SSL encryption to protect your files during upload and processing. All files 
              are automatically deleted from our servers after 1 hour, ensuring your privacy and security.
            </p>
          </article>
        </div>
      </main>

      {/* Schema Markup */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebApplication",
            "name": "Merge PDF - AQPDF",
            "description": "Free online tool to merge multiple PDF files into a single document",
            "url": "https://aqpdf.com/merge-pdf",
            "applicationCategory": "UtilityApplication",
            "offers": {
              "@type": "Offer",
              "price": "0",
              "priceCurrency": "USD"
            }
          })
        }}
      />
    </div>
  );
}
