import { Metadata } from "next";
import Link from "next/link";
import { FileText, ArrowLeft, Upload } from "lucide-react";

export const metadata: Metadata = {
  title: "Image to PDF Converter - Convert JPG/PNG to PDF Online",
  description: "Convert images to PDF online for free. Support JPG, PNG, GIF formats. Create PDF from multiple images.",
  keywords: ["image to pdf", "jpg to pdf", "png to pdf", "convert image to pdf", "photo to pdf"],
  alternates: { canonical: "https://aqpdf.com/image-to-pdf" },
};

export default function ImageToPDFPage() {
  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">AQPDF</span>
            </Link>
            <Link href="/" className="flex items-center space-x-2 text-slate-600 hover:text-blue-600 transition-colors">
              <ArrowLeft className="h-5 w-5" /><span>All Tools</span>
            </Link>
          </div>
        </div>
      </header>
      <main className="py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Image to PDF</h1>
            <p className="text-xl text-slate-600">Convert images to PDF documents</p>
          </div>
          <div className="bg-white rounded-3xl shadow-xl p-12 border-2 border-dashed border-slate-300">
            <div className="text-center">
              <Upload className="h-16 w-16 text-slate-400 mx-auto mb-6" />
              <button className="px-8 py-4 bg-gradient-to-r from-pink-600 to-pink-700 text-white rounded-full font-semibold">Choose Images</button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
