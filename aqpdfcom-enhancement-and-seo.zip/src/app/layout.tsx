import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL('https://aqpdf.com'),
  title: {
    default: "AQPDF - Free Online PDF Tools | Merge, Split, Compress PDFs",
    template: "%s | AQPDF"
  },
  description: "Free online PDF tools to merge, split, compress, convert, and edit PDF files. Fast, secure, and easy to use. No registration required.",
  keywords: ["PDF tools", "merge PDF", "split PDF", "compress PDF", "PDF converter", "edit PDF", "free PDF tools", "online PDF editor"],
  authors: [{ name: "AQPDF" }],
  creator: "AQPDF",
  publisher: "AQPDF",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://aqpdf.com",
    siteName: "AQPDF",
    title: "AQPDF - Free Online PDF Tools",
    description: "Free online PDF tools to merge, split, compress, convert, and edit PDF files. Fast, secure, and easy to use.",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "AQPDF - Free Online PDF Tools",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "AQPDF - Free Online PDF Tools",
    description: "Free online PDF tools to merge, split, compress, convert, and edit PDF files.",
    images: ["/og-image.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  alternates: {
    canonical: "https://aqpdf.com",
  },
  verification: {
    google: "your-google-verification-code",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.svg" type="image/svg+xml" />
        <link rel="icon" href="/icon-192.png" type="image/png" sizes="192x192" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" sizes="180x180" />
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#2563eb" />
      </head>
      <body className="bg-gradient-to-br from-slate-50 to-blue-50 text-slate-900 antialiased">
        {children}
      </body>
    </html>
  );
}
