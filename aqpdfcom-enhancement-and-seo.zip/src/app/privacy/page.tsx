import { Metadata } from "next";
import Link from "next/link";
import { FileText, ArrowLeft, Shield } from "lucide-react";

export const metadata: Metadata = {
  title: "Privacy Policy - AQPDF",
  description: "AQPDF privacy policy. Learn how we protect your data and respect your privacy when using our PDF tools.",
  alternates: {
    canonical: "https://aqpdf.com/privacy",
  },
};

export default function PrivacyPage() {
  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AQPDF
              </span>
            </Link>
            <Link 
              href="/" 
              className="flex items-center space-x-2 text-slate-600 hover:text-blue-600 transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
              <span>Home</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 mb-6">
              <Shield className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Privacy Policy
            </h1>
            <p className="text-slate-600">
              Last updated: January 2024
            </p>
          </div>

          <div className="prose prose-slate max-w-none bg-white rounded-2xl shadow-lg p-8">
            <h2>1. Introduction</h2>
            <p>
              At AQPDF, we take your privacy seriously. This Privacy Policy explains how we collect, 
              use, and protect your information when you use our services.
            </p>

            <h2>2. Information We Collect</h2>
            <h3>2.1 Files You Upload</h3>
            <p>
              When you use our PDF tools, you upload files to our servers for processing. These files 
              are temporarily stored during processing and are automatically deleted after 1 hour.
            </p>

            <h3>2.2 Analytics Data</h3>
            <p>
              We may collect anonymous usage data such as page views, browser type, and device information 
              to improve our services. This data is aggregated and does not identify individual users.
            </p>

            <h2>3. How We Use Your Information</h2>
            <ul>
              <li>To process your PDF files according to the tool you select</li>
              <li>To improve our services and user experience</li>
              <li>To monitor and prevent abuse of our services</li>
              <li>To respond to your support inquiries</li>
            </ul>

            <h2>4. File Security</h2>
            <p>
              All files are encrypted during transfer using SSL/TLS encryption. Files are processed on 
              secure servers and automatically deleted after 1 hour. We do not access, view, or use your 
              files for any purpose other than processing.
            </p>

            <h2>5. Data Sharing</h2>
            <p>
              We do not sell, rent, or share your files or personal information with third parties. 
              Your files remain private and are only accessible to you.
            </p>

            <h2>6. Cookies</h2>
            <p>
              We may use cookies and similar technologies to improve your experience on our website. 
              You can disable cookies in your browser settings, though this may affect some functionality.
            </p>

            <h2>7. Third-Party Services</h2>
            <p>
              We may use third-party services for analytics and advertising. These services may collect 
              anonymous data about your usage. We ensure all third-party services comply with privacy standards.
            </p>

            <h2>8. Your Rights</h2>
            <p>You have the right to:</p>
            <ul>
              <li>Request information about data we collect</li>
              <li>Request deletion of your data</li>
              <li>Opt-out of analytics tracking</li>
              <li>Contact us with privacy concerns</li>
            </ul>

            <h2>9. Children's Privacy</h2>
            <p>
              Our services are not directed to children under 13. We do not knowingly collect information 
              from children under 13.
            </p>

            <h2>10. Changes to This Policy</h2>
            <p>
              We may update this Privacy Policy from time to time. Changes will be posted on this page 
              with an updated date.
            </p>

            <h2>11. Contact Us</h2>
            <p>
              If you have questions about this Privacy Policy, please contact us at:
              <br />
              Email: <a href="mailto:privacy@aqpdf.com">privacy@aqpdf.com</a>
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
