import { Metadata } from "next";
import Link from "next/link";
import { FileText, Scissors, ArrowLeft, Upload } from "lucide-react";

export const metadata: Metadata = {
  title: "Split PDF Online - Extract Pages from PDF",
  description: "Free online tool to split PDF files. Extract specific pages or split into multiple documents. Fast, easy, and secure.",
  keywords: ["split pdf", "extract pdf pages", "divide pdf", "pdf splitter", "split pdf online free"],
  alternates: {
    canonical: "https://aqpdf.com/split-pdf",
  },
};

export default function SplitPDFPage() {
  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AQPDF
              </span>
            </Link>
            <Link href="/" className="flex items-center space-x-2 text-slate-600 hover:text-blue-600 transition-colors">
              <ArrowLeft className="h-5 w-5" />
              <span>All Tools</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-purple-500 to-purple-600 mb-6">
              <Scissors className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Split PDF Files</h1>
            <p className="text-xl text-slate-600">Extract pages or split PDF into multiple documents</p>
          </div>

          <div className="bg-white rounded-3xl shadow-xl p-12 mb-12 border-2 border-dashed border-slate-300 hover:border-purple-500 transition-colors">
            <div className="text-center">
              <Upload className="h-16 w-16 text-slate-400 mx-auto mb-6" />
              <h3 className="text-2xl font-semibold mb-2">Select PDF File</h3>
              <p className="text-slate-600 mb-6">Choose a PDF file to split</p>
              <button className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-full font-semibold hover:shadow-xl transition-all transform hover:scale-105">
                <Upload className="mr-2 h-5 w-5" />
                Choose File
              </button>
            </div>
          </div>

          <article className="prose prose-slate max-w-none">
            <h2>How to Split PDF Files</h2>
            <p>Splitting PDFs allows you to extract specific pages or divide a large document into smaller files.</p>
            
            <h3>Split Options</h3>
            <ul>
              <li>Extract specific pages</li>
              <li>Split by page ranges</li>
              <li>Split into individual pages</li>
              <li>Remove unwanted pages</li>
            </ul>
          </article>
        </div>
      </main>
    </div>
  );
}
