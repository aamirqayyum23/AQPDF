import { Metadata } from "next";
import Link from "next/link";
import { FileText, Minimize2, ArrowLeft, Upload } from "lucide-react";

export const metadata: Metadata = {
  title: "Compress PDF Online - Reduce PDF File Size",
  description: "Free online PDF compressor to reduce PDF file size without losing quality. Compress large PDFs for email and web sharing.",
  keywords: ["compress pdf", "reduce pdf size", "pdf compressor", "shrink pdf", "compress pdf online free"],
  alternates: {
    canonical: "https://aqpdf.com/compress-pdf",
  },
  openGraph: {
    title: "Compress PDF Online - AQPDF",
    description: "Reduce PDF file size without losing quality",
    url: "https://aqpdf.com/compress-pdf",
  },
};

export default function CompressPDFPage() {
  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AQPDF
              </span>
            </Link>
            <Link 
              href="/" 
              className="flex items-center space-x-2 text-slate-600 hover:text-blue-600 transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
              <span>All Tools</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-green-500 to-green-600 mb-6">
              <Minimize2 className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Compress PDF
            </h1>
            <p className="text-xl text-slate-600">
              Reduce PDF file size while maintaining quality
            </p>
          </div>

          <div className="bg-white rounded-3xl shadow-xl p-12 mb-12 border-2 border-dashed border-slate-300 hover:border-green-500 transition-colors">
            <div className="text-center">
              <Upload className="h-16 w-16 text-slate-400 mx-auto mb-6" />
              <h3 className="text-2xl font-semibold mb-2">Select PDF File</h3>
              <p className="text-slate-600 mb-6">
                Choose a PDF file to compress
              </p>
              <button className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-green-600 to-green-700 text-white rounded-full font-semibold hover:shadow-xl transition-all transform hover:scale-105">
                <Upload className="mr-2 h-5 w-5" />
                Choose File
              </button>
            </div>
          </div>

          <article className="prose prose-slate max-w-none">
            <h2>About PDF Compression</h2>
            <p>
              Compress your PDF files to reduce their size without compromising quality. Perfect for 
              email attachments, web uploads, and storage optimization.
            </p>
            
            <h3>Compression Levels</h3>
            <ul>
              <li><strong>Low Compression:</strong> Minimal size reduction, maximum quality</li>
              <li><strong>Medium Compression:</strong> Balanced size reduction and quality</li>
              <li><strong>High Compression:</strong> Maximum size reduction, good quality</li>
            </ul>

            <h3>Why Compress PDFs?</h3>
            <p>
              Large PDF files can be difficult to share via email and may take longer to load. 
              Compressing PDFs makes them easier to send, faster to download, and saves storage space.
            </p>
          </article>
        </div>
      </main>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebApplication",
            "name": "Compress PDF - AQPDF",
            "description": "Free online tool to compress PDF files and reduce file size",
            "url": "https://aqpdf.com/compress-pdf",
            "applicationCategory": "UtilityApplication"
          })
        }}
      />
    </div>
  );
}
